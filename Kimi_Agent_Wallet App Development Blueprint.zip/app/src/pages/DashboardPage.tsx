import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Wallet, 
  ArrowUpRight, 
  ArrowDownLeft, 
  History, 
  User, 
  Users, 
  Building2,
  ChevronRight,
  Bell,
  Sparkles
} from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { MOBICASH_OFFERS, BANNER_OFFERS } from '@/data/offers';
import { toast } from 'sonner';

interface DashboardPageProps {
  onNavigate: (page: 'login' | 'signup' | 'dashboard' | 'send' | 'receive' | 'history' | 'offer' | 'market' | 'profile') => void;
  onOfferClick: (offerId: string) => void;
}

export function DashboardPage({ onNavigate, onOfferClick }: DashboardPageProps) {
  const { user } = useAuth();
  const [showBalance, setShowBalance] = useState(true);
  const [currentBanner, setCurrentBanner] = useState(0);

  // Auto-rotate banners
  useState(() => {
    const interval = setInterval(() => {
      setCurrentBanner((prev) => (prev + 1) % BANNER_OFFERS.length);
    }, 4000);
    return () => clearInterval(interval);
  });

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('fr-DZ', {
      style: 'currency',
      currency: 'DZD',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const quickActions = [
    {
      id: 'send',
      icon: ArrowUpRight,
      label: 'Envoyer',
      color: 'bg-emerald-500',
      onClick: () => onNavigate('send'),
    },
    {
      id: 'receive',
      icon: ArrowDownLeft,
      label: 'Recevoir',
      color: 'bg-blue-500',
      onClick: () => onNavigate('receive'),
    },
    {
      id: 'history',
      icon: History,
      label: 'Historique',
      color: 'bg-purple-500',
      onClick: () => onNavigate('history'),
    },
  ];

  const getOfferIcon = (iconName: string) => {
    switch (iconName) {
      case 'User': return User;
      case 'Users': return Users;
      case 'Building2': return Building2;
      default: return Wallet;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white p-4 pb-8">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
              <span className="text-lg font-bold">{user?.name.charAt(0)}</span>
            </div>
            <div>
              <p className="text-sm text-emerald-100">Bonjour,</p>
              <p className="font-semibold">{user?.name.split(' ')[0]}</p>
            </div>
          </div>
          <button 
            onClick={() => toast.info('Notifications à venir !')}
            className="relative w-10 h-10 bg-white/20 rounded-full flex items-center justify-center"
          >
            <Bell className="w-5 h-5" />
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-xs flex items-center justify-center">
              2
            </span>
          </button>
        </div>
      </header>

      {/* Main Content */}
      <div className="px-4 -mt-4">
        {/* Balance Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-lg p-6 mb-6"
        >
          <div className="flex items-center justify-between mb-4">
            <span className="text-gray-500 text-sm">Solde disponible</span>
            <button 
              onClick={() => setShowBalance(!showBalance)}
              className="text-gray-400 hover:text-gray-600"
            >
              {showBalance ? 'Masquer' : 'Afficher'}
            </button>
          </div>
          
          <button 
            onClick={() => onNavigate('history')}
            className="w-full text-left group"
          >
            <motion.div 
              className="text-3xl font-bold text-gray-800 mb-1"
              whileTap={{ scale: 0.98 }}
            >
              {showBalance ? formatCurrency(user?.balance || 0) : '•••••• DZD'}
            </motion.div>
            <div className="flex items-center text-emerald-600 text-sm group-hover:text-emerald-700">
              <span>Voir l'historique</span>
              <ChevronRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
            </div>
          </button>

          {/* Flexy Balance */}
          <div className="mt-4 pt-4 border-t border-gray-100 flex items-center justify-between">
            <span className="text-gray-500 text-sm">Solde Flexy</span>
            <span className="font-semibold text-emerald-600">
              {showBalance ? `${user?.flexyBalance} DA` : '••••'}
            </span>
          </div>
        </motion.div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-3 gap-4 mb-6"
        >
          {quickActions.map((action) => (
            <motion.button
              key={action.id}
              onClick={action.onClick}
              whileTap={{ scale: 0.95 }}
              className="flex flex-col items-center gap-2"
            >
              <div className={`w-14 h-14 ${action.color} rounded-2xl flex items-center justify-center shadow-lg`}>
                <action.icon className="w-6 h-6 text-white" />
              </div>
              <span className="text-sm font-medium text-gray-700">{action.label}</span>
            </motion.button>
          ))}
        </motion.div>

        {/* Rotating Banner */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-6"
        >
          <h3 className="text-lg font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-500" />
            Offres du moment
          </h3>
          <div className="overflow-hidden rounded-2xl">
            <motion.div
              animate={{ x: `-${currentBanner * 100}%` }}
              transition={{ duration: 0.5 }}
              className="flex"
            >
              {BANNER_OFFERS.map((banner) => (
                <div
                  key={banner.id}
                  className={`w-full flex-shrink-0 bg-gradient-to-r ${banner.color} p-4 text-white`}
                >
                  <h4 className="font-bold text-lg">{banner.title}</h4>
                  <p className="text-white/90 text-sm">{banner.subtitle}</p>
                </div>
              ))}
            </motion.div>
          </div>
          <div className="flex justify-center gap-2 mt-2">
            {BANNER_OFFERS.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentBanner(index)}
                className={`w-2 h-2 rounded-full transition-all ${
                  index === currentBanner ? 'bg-emerald-500 w-4' : 'bg-gray-300'
                }`}
              />
            ))}
          </div>
        </motion.div>

        {/* Offers Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mb-6"
        >
          <h3 className="text-lg font-semibold text-gray-800 mb-3">Nos offres</h3>
          <div className="space-y-3">
            {MOBICASH_OFFERS.map((offer, index) => {
              const Icon = getOfferIcon(offer.icon);
              return (
                <motion.button
                  key={offer.id}
                  onClick={() => onOfferClick(offer.id)}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + index * 0.1 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full bg-white rounded-2xl p-4 shadow-sm border border-gray-100 flex items-center gap-4"
                >
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${offer.color} flex items-center justify-center`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1 text-left">
                    <h4 className="font-semibold text-gray-800">{offer.name}</h4>
                    <p className="text-sm text-gray-500 line-clamp-1">{offer.description}</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                </motion.button>
              );
            })}
          </div>
        </motion.div>

        {/* Trust Badge */}
        <div className="text-center py-4">
          <p className="text-xs text-gray-400">
            Sécurisé par Bank of Algeria • Mobilis
          </p>
        </div>
      </div>
    </div>
  );
}
