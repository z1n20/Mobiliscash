import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Ticket, 
  Tv, 
  Gamepad2, 
  Search,
  ChevronRight,
  Star,
  ShoppingCart
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { MARKET_OFFERS } from '@/data/offers';
import { toast } from 'sonner';

interface MarketPageProps {
  onNavigate: (page: 'login' | 'signup' | 'dashboard' | 'send' | 'receive' | 'history' | 'offer' | 'market' | 'profile') => void;
}

type Category = 'all' | 'tickets' | 'streaming' | 'gaming';

export function MarketPage({ onNavigate: _onNavigate }: MarketPageProps) {
  const [activeCategory, setActiveCategory] = useState<Category>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [cart, setCart] = useState<string[]>([]);

  const categories = [
    { id: 'all' as Category, label: 'Tout', icon: Star },
    { id: 'tickets' as Category, label: 'Tickets', icon: Ticket },
    { id: 'streaming' as Category, label: 'Streaming', icon: Tv },
    { id: 'gaming' as Category, label: 'Gaming', icon: Gamepad2 },
  ];

  const filteredOffers = MARKET_OFFERS.filter(offer => {
    const matchesCategory = activeCategory === 'all' || offer.category === activeCategory;
    const matchesSearch = offer.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         offer.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const addToCart = (offerId: string) => {
    if (cart.includes(offerId)) {
      toast.info('Déjà dans le panier');
      return;
    }
    setCart([...cart, offerId]);
    toast.success('Ajouté au panier !');
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('fr-DZ', {
      style: 'currency',
      currency: 'DZD',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'tickets':
        return 'from-red-500 to-rose-600';
      case 'streaming':
        return 'from-purple-500 to-violet-600';
      case 'gaming':
        return 'from-green-500 to-emerald-600';
      default:
        return 'from-emerald-500 to-teal-600';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'tickets':
        return Ticket;
      case 'streaming':
        return Tv;
      case 'gaming':
        return Gamepad2;
      default:
        return Star;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white p-4 pb-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold">Marketplace</h1>
            <p className="text-emerald-100 text-sm">Découvrez nos offres exclusives</p>
          </div>
          <button 
            onClick={() => toast.info(`Panier: ${cart.length} article(s)`)}
            className="relative w-12 h-12 bg-white/20 rounded-full flex items-center justify-center"
          >
            <ShoppingCart className="w-6 h-6" />
            {cart.length > 0 && (
              <span className="absolute -top-1 -right-1 w-6 h-6 bg-red-500 rounded-full text-xs flex items-center justify-center font-bold">
                {cart.length}
              </span>
            )}
          </button>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <Input
            placeholder="Rechercher une offre..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 h-12 rounded-xl bg-white/90 border-0 text-gray-800 placeholder:text-gray-400"
          />
        </div>
      </header>

      <div className="p-4">
        {/* Categories */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex gap-2 overflow-x-auto pb-2 mb-6 scrollbar-hide"
        >
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`flex items-center gap-2 px-4 py-3 rounded-xl whitespace-nowrap transition-all ${
                activeCategory === cat.id
                  ? 'bg-emerald-500 text-white shadow-lg'
                  : 'bg-white text-gray-600 border border-gray-200 hover:border-emerald-300'
              }`}
            >
              <cat.icon className="w-4 h-4" />
              <span className="font-medium">{cat.label}</span>
            </button>
          ))}
        </motion.div>

        {/* Featured Banner */}
        {activeCategory === 'all' && !searchQuery && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mb-6"
          >
            <div className="bg-gradient-to-r from-red-500 to-rose-600 rounded-2xl p-5 text-white relative overflow-hidden">
              <div className="relative z-10">
                <span className="inline-block bg-white/20 rounded-full px-3 py-1 text-xs font-medium mb-3">
                  En vedette
                </span>
                <h3 className="text-xl font-bold mb-1">Mobilis Ligue 1</h3>
                <p className="text-white/90 text-sm mb-3">Réservez vos places pour les matchs</p>
                <Button 
                  onClick={() => setActiveCategory('tickets')}
                  className="bg-white text-red-600 hover:bg-gray-100 rounded-xl"
                >
                  Voir les tickets
                  <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </div>
              <div className="absolute right-0 top-0 w-32 h-32 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2" />
              <div className="absolute right-10 bottom-0 w-20 h-20 bg-white/10 rounded-full translate-y-1/2" />
            </div>
          </motion.div>
        )}

        {/* Offers Grid */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeCategory + searchQuery}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="grid grid-cols-2 gap-4"
          >
            {filteredOffers.map((offer, index) => {
              const CategoryIcon = getCategoryIcon(offer.category);
              return (
                <motion.div
                  key={offer.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100"
                >
                  {/* Image */}
                  <div className="relative h-32 overflow-hidden">
                    <img
                      src={offer.image}
                      alt={offer.title}
                      className="w-full h-full object-cover"
                    />
                    <div className={`absolute top-2 left-2 w-8 h-8 rounded-lg bg-gradient-to-br ${getCategoryColor(offer.category)} flex items-center justify-center`}>
                      <CategoryIcon className="w-4 h-4 text-white" />
                    </div>
                    {offer.badge && (
                      <span className="absolute top-2 right-2 bg-amber-500 text-white text-xs font-medium px-2 py-1 rounded-full">
                        {offer.badge}
                      </span>
                    )}
                  </div>

                  {/* Content */}
                  <div className="p-3">
                    <h3 className="font-semibold text-gray-800 text-sm mb-1 line-clamp-1">
                      {offer.title}
                    </h3>
                    <p className="text-xs text-gray-500 mb-2 line-clamp-2">
                      {offer.description}
                    </p>
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-emerald-600">
                        {formatCurrency(offer.price)}
                      </span>
                      <button
                        onClick={() => addToCart(offer.id)}
                        className="w-8 h-8 bg-emerald-100 rounded-lg flex items-center justify-center hover:bg-emerald-200 transition-colors"
                      >
                        <ShoppingCart className="w-4 h-4 text-emerald-600" />
                      </button>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </motion.div>
        </AnimatePresence>

        {filteredOffers.length === 0 && (
          <div className="text-center py-12">
            <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="w-10 h-10 text-gray-400" />
            </div>
            <h3 className="text-lg font-semibold text-gray-600 mb-2">Aucune offre trouvée</h3>
            <p className="text-gray-500">Essayez une autre recherche</p>
          </div>
        )}

        {/* Categories Summary */}
        {!searchQuery && activeCategory === 'all' && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="mt-8 space-y-4"
          >
            <h3 className="text-lg font-semibold text-gray-800">Explorer par catégorie</h3>
            
            {/* Tickets */}
            <button
              onClick={() => setActiveCategory('tickets')}
              className="w-full bg-white rounded-2xl p-4 flex items-center gap-4 shadow-sm border border-gray-100 hover:border-red-300 transition-colors"
            >
              <div className="w-14 h-14 bg-gradient-to-br from-red-500 to-rose-600 rounded-xl flex items-center justify-center">
                <Ticket className="w-7 h-7 text-white" />
              </div>
              <div className="flex-1 text-left">
                <h4 className="font-semibold text-gray-800">Tickets & Événements</h4>
                <p className="text-sm text-gray-500">Stade, concerts, spectacles</p>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>

            {/* Streaming */}
            <button
              onClick={() => setActiveCategory('streaming')}
              className="w-full bg-white rounded-2xl p-4 flex items-center gap-4 shadow-sm border border-gray-100 hover:border-purple-300 transition-colors"
            >
              <div className="w-14 h-14 bg-gradient-to-br from-purple-500 to-violet-600 rounded-xl flex items-center justify-center">
                <Tv className="w-7 h-7 text-white" />
              </div>
              <div className="flex-1 text-left">
                <h4 className="font-semibold text-gray-800">Streaming & TV</h4>
                <p className="text-sm text-gray-500">Netflix, HBO, Amazon Prime</p>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>

            {/* Gaming */}
            <button
              onClick={() => setActiveCategory('gaming')}
              className="w-full bg-white rounded-2xl p-4 flex items-center gap-4 shadow-sm border border-gray-100 hover:border-green-300 transition-colors"
            >
              <div className="w-14 h-14 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center">
                <Gamepad2 className="w-7 h-7 text-white" />
              </div>
              <div className="flex-1 text-left">
                <h4 className="font-semibold text-gray-800">Gaming</h4>
                <p className="text-sm text-gray-500">Game Pass, PlayStation Plus</p>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </button>
          </motion.div>
        )}
      </div>
    </div>
  );
}
