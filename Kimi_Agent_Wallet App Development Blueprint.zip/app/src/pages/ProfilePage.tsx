import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  User, 
  Phone, 
  Mail, 
  CreditCard, 
  Settings, 
  Shield, 
  HelpCircle, 
  LogOut,
  ChevronRight,
  Bell,
  Wallet,
  Edit3
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/useAuth';
import { toast } from 'sonner';

interface ProfilePageProps {
  onNavigate: (page: 'login' | 'signup' | 'dashboard' | 'send' | 'receive' | 'history' | 'offer' | 'market' | 'profile') => void;
}

export function ProfilePage({ onNavigate }: ProfilePageProps) {
  const { user, logout } = useAuth();
  const [_isEditing, _setIsEditing] = useState(false);

  const handleLogout = () => {
    logout();
    toast.success('Déconnexion réussie');
    onNavigate('login');
  };

  const menuItems = [
    {
      id: 'personal',
      title: 'Informations personnelles',
      icon: User,
      color: 'bg-blue-100 text-blue-600',
      onClick: () => toast.info('Modification à venir !'),
    },
    {
      id: 'security',
      title: 'Sécurité',
      icon: Shield,
      color: 'bg-emerald-100 text-emerald-600',
      onClick: () => toast.info('Sécurité à venir !'),
    },
    {
      id: 'notifications',
      title: 'Notifications',
      icon: Bell,
      color: 'bg-amber-100 text-amber-600',
      onClick: () => toast.info('Paramètres de notifications à venir !'),
    },
    {
      id: 'settings',
      title: 'Paramètres',
      icon: Settings,
      color: 'bg-gray-100 text-gray-600',
      onClick: () => toast.info('Paramètres à venir !'),
    },
    {
      id: 'help',
      title: 'Aide & Support',
      icon: HelpCircle,
      color: 'bg-purple-100 text-purple-600',
      onClick: () => toast.info('Support à venir !'),
    },
  ];

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('fr-DZ', {
      style: 'currency',
      currency: 'DZD',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white p-4 pb-12">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-xl font-semibold">Mon Profil</h1>
          <button 
            onClick={() => toast.info('Notifications à venir !')}
            className="relative w-10 h-10 bg-white/20 rounded-full flex items-center justify-center"
          >
            <Bell className="w-5 h-5" />
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-xs flex items-center justify-center">
              2
            </span>
          </button>
        </div>
      </header>

      <div className="px-4 -mt-8">
        {/* Profile Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl shadow-lg p-6 mb-6"
        >
          <div className="flex items-center gap-4 mb-6">
            <div className="relative">
              <div className="w-20 h-20 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-full flex items-center justify-center">
                <span className="text-3xl font-bold text-white">{user?.name.charAt(0)}</span>
              </div>
              <button 
                onClick={() => toast.info('Photo de profil à venir !')}
                className="absolute -bottom-1 -right-1 w-8 h-8 bg-white rounded-full shadow-md flex items-center justify-center border border-gray-100"
              >
                <Edit3 className="w-4 h-4 text-gray-600" />
              </button>
            </div>
            <div className="flex-1">
              <h2 className="text-xl font-bold text-gray-800">{user?.name}</h2>
              <p className="text-gray-500">{user?.phone}</p>
              <span className="inline-flex items-center gap-1 bg-emerald-100 text-emerald-700 text-xs font-medium px-2 py-1 rounded-full mt-1">
                <Shield className="w-3 h-3" />
                Vérifié
              </span>
            </div>
          </div>

          {/* Balance Summary */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-emerald-50 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-1">
                <Wallet className="w-4 h-4 text-emerald-600" />
                <span className="text-sm text-gray-600">Wallet</span>
              </div>
              <p className="text-lg font-bold text-emerald-700">
                {formatCurrency(user?.balance || 0)}
              </p>
            </div>
            <div className="bg-blue-50 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-1">
                <Phone className="w-4 h-4 text-blue-600" />
                <span className="text-sm text-gray-600">Flexy</span>
              </div>
              <p className="text-lg font-bold text-blue-700">
                {user?.flexyBalance} DA
              </p>
            </div>
          </div>
        </motion.div>

        {/* User Details */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white rounded-2xl shadow-sm p-5 mb-6"
        >
          <h3 className="text-sm font-medium text-gray-500 mb-4 uppercase tracking-wide">
            Informations
          </h3>
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <Mail className="w-5 h-5 text-blue-600" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-gray-500">Email</p>
                <p className="font-medium text-gray-800">{user?.email}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center">
                <Phone className="w-5 h-5 text-emerald-600" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-gray-500">Téléphone</p>
                <p className="font-medium text-gray-800">{user?.phone}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-amber-100 rounded-lg flex items-center justify-center">
                <CreditCard className="w-5 h-5 text-amber-600" />
              </div>
              <div className="flex-1">
                <p className="text-sm text-gray-500">NIN</p>
                <p className="font-medium text-gray-800 font-mono">
                  {user?.nin.replace(/(\d{4})/g, '$1 ').trim()}
                </p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Menu */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="space-y-3"
        >
          <h3 className="text-sm font-medium text-gray-500 mb-4 uppercase tracking-wide px-1">
            Paramètres
          </h3>
          {menuItems.map((item, index) => (
            <motion.button
              key={item.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 + index * 0.05 }}
              onClick={item.onClick}
              className="w-full bg-white rounded-xl p-4 flex items-center gap-4 shadow-sm border border-gray-100 hover:border-emerald-300 transition-colors"
            >
              <div className={`w-10 h-10 ${item.color} rounded-lg flex items-center justify-center`}>
                <item.icon className="w-5 h-5" />
              </div>
              <span className="flex-1 text-left font-medium text-gray-700">{item.title}</span>
              <ChevronRight className="w-5 h-5 text-gray-400" />
            </motion.button>
          ))}
        </motion.div>

        {/* App Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mt-8 text-center"
        >
          <div className="flex items-center justify-center gap-2 mb-2">
            <div className="w-8 h-8 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-lg flex items-center justify-center">
              <Wallet className="w-4 h-4 text-white" />
            </div>
            <span className="font-semibold text-gray-800">MOBICASH</span>
          </div>
          <p className="text-sm text-gray-500">Version 1.0.0</p>
          <p className="text-xs text-gray-400 mt-1">
            Propulsé par Mobilis
          </p>
        </motion.div>

        {/* Logout */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="mt-6 mb-8"
        >
          <Button
            onClick={handleLogout}
            variant="outline"
            className="w-full h-12 rounded-xl border-red-200 text-red-600 hover:bg-red-50 flex items-center justify-center gap-2"
          >
            <LogOut className="w-5 h-5" />
            Déconnexion
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
