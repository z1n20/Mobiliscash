import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  ArrowUpRight, 
  ArrowDownLeft, 
  ShoppingBag,
  Search,
  Calendar
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { useTransactions } from '@/hooks/useTransactions';

interface TransactionHistoryPageProps {
  onNavigate: (page: 'login' | 'signup' | 'dashboard' | 'send' | 'receive' | 'history' | 'offer' | 'market' | 'profile') => void;
}

type FilterType = 'all' | 'send' | 'receive' | 'purchase';

export function TransactionHistoryPage({ onNavigate }: TransactionHistoryPageProps) {
  const { transactions } = useTransactions();
  const [searchQuery, setSearchQuery] = useState('');
  const [filter, setFilter] = useState<FilterType>('all');

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('fr-DZ', {
      style: 'currency',
      currency: 'DZD',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));

    if (diffDays === 0) {
      return `Aujourd'hui, ${date.toLocaleTimeString('fr-DZ', { hour: '2-digit', minute: '2-digit' })}`;
    } else if (diffDays === 1) {
      return `Hier, ${date.toLocaleTimeString('fr-DZ', { hour: '2-digit', minute: '2-digit' })}`;
    } else {
      return date.toLocaleDateString('fr-DZ', { day: 'numeric', month: 'short', year: 'numeric' });
    }
  };

  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'send':
        return { icon: ArrowUpRight, color: 'bg-red-100 text-red-600', sign: '-' };
      case 'receive':
        return { icon: ArrowDownLeft, color: 'bg-emerald-100 text-emerald-600', sign: '+' };
      case 'purchase':
        return { icon: ShoppingBag, color: 'bg-blue-100 text-blue-600', sign: '-' };
      default:
        return { icon: ArrowUpRight, color: 'bg-gray-100 text-gray-600', sign: '' };
    }
  };

  const getTransactionLabel = (type: string) => {
    switch (type) {
      case 'send':
        return 'Envoyé';
      case 'receive':
        return 'Reçu';
      case 'purchase':
        return 'Achat';
      default:
        return type;
    }
  };

  const filteredTransactions = transactions.filter(t => {
    const matchesFilter = filter === 'all' || t.type === filter;
    const matchesSearch = 
      t.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (t.recipient && t.recipient.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (t.sender && t.sender.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesFilter && matchesSearch;
  });

  // Group transactions by date
  const groupedTransactions = filteredTransactions.reduce((groups, transaction) => {
    const date = new Date(transaction.date).toDateString();
    if (!groups[date]) {
      groups[date] = [];
    }
    groups[date].push(transaction);
    return groups;
  }, {} as Record<string, typeof transactions>);

  const filters: { id: FilterType; label: string }[] = [
    { id: 'all', label: 'Tout' },
    { id: 'receive', label: 'Reçus' },
    { id: 'send', label: 'Envoyés' },
    { id: 'purchase', label: 'Achats' },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white px-4 py-4 flex items-center gap-4 border-b border-gray-100 sticky top-0 z-10">
        <button 
          onClick={() => onNavigate('dashboard')}
          className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center"
        >
          <ArrowLeft className="w-5 h-5 text-gray-600" />
        </button>
        <h1 className="text-xl font-semibold text-gray-800">Historique</h1>
      </header>

      <div className="p-4">
        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <Input
            placeholder="Rechercher une transaction..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 h-12 rounded-xl border-gray-200"
          />
        </div>

        {/* Filters */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2 scrollbar-hide">
          {filters.map((f) => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id)}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
                filter === f.id
                  ? 'bg-emerald-500 text-white'
                  : 'bg-white text-gray-600 border border-gray-200 hover:border-emerald-300'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        {/* Summary Card */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-emerald-500 to-teal-600 rounded-2xl p-5 text-white mb-6"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-emerald-100 text-sm mb-1">Ce mois</p>
              <p className="text-2xl font-bold">
                {formatCurrency(
                  transactions
                    .filter(t => t.type === 'receive')
                    .reduce((sum, t) => sum + t.amount, 0)
                )}
              </p>
              <p className="text-emerald-100 text-sm">reçus</p>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold">
                {formatCurrency(
                  transactions
                    .filter(t => t.type === 'send' || t.type === 'purchase')
                    .reduce((sum, t) => sum + t.amount, 0)
                )}
              </p>
              <p className="text-emerald-100 text-sm">dépensés</p>
            </div>
          </div>
        </motion.div>

        {/* Transactions List */}
        <div className="space-y-6">
          {Object.entries(groupedTransactions).length === 0 ? (
            <div className="text-center py-12">
              <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Calendar className="w-10 h-10 text-gray-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-600 mb-2">Aucune transaction</h3>
              <p className="text-gray-500">Vos transactions apparaîtront ici</p>
            </div>
          ) : (
            Object.entries(groupedTransactions).map(([date, dayTransactions], groupIndex) => (
              <motion.div
                key={date}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: groupIndex * 0.1 }}
              >
                <h3 className="text-sm font-medium text-gray-500 mb-3">
                  {new Date(date).toLocaleDateString('fr-DZ', { 
                    weekday: 'long', 
                    day: 'numeric', 
                    month: 'long' 
                  })}
                </h3>
                <div className="space-y-3">
                  {dayTransactions.map((transaction, index) => {
                    const { icon: Icon, color, sign } = getTransactionIcon(transaction.type);
                    return (
                      <motion.div
                        key={transaction.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.05 }}
                        className="bg-white rounded-xl p-4 flex items-center gap-4 shadow-sm"
                      >
                        <div className={`w-12 h-12 ${color} rounded-xl flex items-center justify-center`}>
                          <Icon className="w-6 h-6" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-gray-800">
                            {transaction.description}
                          </p>
                          <p className="text-sm text-gray-500">
                            {transaction.recipient && `À: ${transaction.recipient}`}
                            {transaction.sender && `De: ${transaction.sender}`}
                            {!transaction.recipient && !transaction.sender && getTransactionLabel(transaction.type)}
                          </p>
                        </div>
                        <div className="text-right">
                          <p className={`font-semibold ${sign === '+' ? 'text-emerald-600' : 'text-gray-800'}`}>
                            {sign}{formatCurrency(transaction.amount)}
                          </p>
                          <p className="text-xs text-gray-400">
                            {formatDate(transaction.date)}
                          </p>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </motion.div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
