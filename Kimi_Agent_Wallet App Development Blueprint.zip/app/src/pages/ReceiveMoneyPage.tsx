import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  QrCode, 
  Share2, 
  Copy, 
  Link,
  Check
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/useAuth';
import { QRCodeSVG } from 'qrcode.react';
import { toast } from 'sonner';

interface ReceiveMoneyPageProps {
  onNavigate: (page: 'login' | 'signup' | 'dashboard' | 'send' | 'receive' | 'history' | 'offer' | 'market' | 'profile') => void;
}

export function ReceiveMoneyPage({ onNavigate }: ReceiveMoneyPageProps) {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'qr' | 'link'>('qr');
  const [copied, setCopied] = useState(false);
  const [amount, setAmount] = useState('');

  // Generate QR data
  const qrData = JSON.stringify({
    type: 'mobicash_transfer',
    phone: user?.phone,
    name: user?.name,
    amount: amount || null,
  });

  // Generate payment link
  const paymentLink = `https://mobicash.dz/pay/${user?.phone}${amount ? `?amount=${amount}` : ''}`;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    toast.success('Copié dans le presse-papiers !');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Paiement MOBICASH',
          text: `Payez-moi via MOBICASH: ${paymentLink}`,
          url: paymentLink,
        });
      } catch (error) {
        handleCopy(paymentLink);
      }
    } else {
      handleCopy(paymentLink);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('fr-DZ', {
      style: 'currency',
      currency: 'DZD',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white px-4 py-4 flex items-center gap-4 border-b border-gray-100 sticky top-0 z-10">
        <button 
          onClick={() => onNavigate('dashboard')}
          className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center"
        >
          <ArrowLeft className="w-5 h-5 text-gray-600" />
        </button>
        <h1 className="text-xl font-semibold text-gray-800">Recevoir de l'argent</h1>
      </header>

      <div className="p-4">
        {/* Tabs */}
        <div className="flex bg-white rounded-xl p-1 mb-6 shadow-sm">
          <button
            onClick={() => setActiveTab('qr')}
            className={`flex-1 py-3 px-4 rounded-lg text-sm font-medium transition-all flex items-center justify-center gap-2 ${
              activeTab === 'qr'
                ? 'bg-emerald-500 text-white'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            <QrCode className="w-4 h-4" />
            QR Code
          </button>
          <button
            onClick={() => setActiveTab('link')}
            className={`flex-1 py-3 px-4 rounded-lg text-sm font-medium transition-all flex items-center justify-center gap-2 ${
              activeTab === 'link'
                ? 'bg-emerald-500 text-white'
                : 'text-gray-500 hover:text-gray-700'
            }`}
          >
            <Link className="w-4 h-4" />
            Lien de paiement
          </button>
        </div>

        {/* Amount Input */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-2xl p-4 mb-6 shadow-sm"
        >
          <label className="text-sm text-gray-500 mb-2 block">Montant demandé (optionnel)</label>
          <div className="flex items-center gap-2">
            <input
              type="number"
              placeholder="0"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="flex-1 text-3xl font-bold text-gray-800 outline-none"
            />
            <span className="text-xl text-gray-500">DZD</span>
          </div>
        </motion.div>

        {/* QR Code Tab */}
        {activeTab === 'qr' && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="space-y-6"
          >
            {/* QR Card */}
            <div className="bg-white rounded-3xl p-8 shadow-lg">
              {/* User Info */}
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-2xl font-bold text-white">{user?.name.charAt(0)}</span>
                </div>
                <h3 className="font-semibold text-gray-800">{user?.name}</h3>
                <p className="text-gray-500 text-sm">{user?.phone}</p>
              </div>

              {/* QR Code */}
              <div className="flex justify-center mb-6">
                <div className="p-4 bg-white rounded-2xl border-2 border-dashed border-gray-200">
                  <QRCodeSVG
                    value={qrData}
                    size={200}
                    level="H"
                    includeMargin={false}
                    imageSettings={{
                      src: '/mobicash-logo.png',
                      height: 30,
                      width: 30,
                      excavate: true,
                    }}
                  />
                </div>
              </div>

              {/* Amount Display */}
              {amount && (
                <div className="text-center mb-4">
                  <p className="text-2xl font-bold text-emerald-600">
                    {formatCurrency(parseFloat(amount))}
                  </p>
                </div>
              )}

              <p className="text-center text-gray-500 text-sm">
                Scannez ce code pour m'envoyer de l'argent
              </p>
            </div>

            {/* Actions */}
            <div className="grid grid-cols-2 gap-3">
              <Button
                variant="outline"
                onClick={() => handleCopy(qrData)}
                className="h-12 rounded-xl border-gray-300 flex items-center gap-2"
              >
                {copied ? <Check className="w-5 h-5 text-emerald-600" /> : <Copy className="w-5 h-5" />}
                {copied ? 'Copié' : 'Copier'}
              </Button>
              <Button
                onClick={handleShare}
                className="h-12 bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-xl flex items-center gap-2"
              >
                <Share2 className="w-5 h-5" />
                Partager
              </Button>
            </div>

            {/* Info */}
            <div className="bg-emerald-50 rounded-xl p-4">
              <h4 className="font-semibold text-emerald-800 mb-2 flex items-center gap-2">
                <QrCode className="w-5 h-5" />
                Comment ça marche ?
              </h4>
              <ol className="text-sm text-emerald-700 space-y-2 list-decimal list-inside">
                <li>Le payeur scanne votre QR code avec l'app MOBICASH</li>
                <li>Il confirme le montant et valide le transfert</li>
                <li>L'argent est instantanément crédité sur votre compte</li>
              </ol>
            </div>
          </motion.div>
        )}

        {/* Link Tab */}
        {activeTab === 'link' && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="space-y-6"
          >
            {/* Link Card */}
            <div className="bg-white rounded-3xl p-6 shadow-lg">
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center mx-auto mb-3">
                  <Link className="w-8 h-8 text-white" />
                </div>
                <h3 className="font-semibold text-gray-800">Lien de paiement</h3>
                <p className="text-gray-500 text-sm">Partagez ce lien pour recevoir de l'argent</p>
              </div>

              {/* Link Display */}
              <div className="bg-gray-100 rounded-xl p-4 mb-4">
                <p className="text-sm text-gray-600 break-all font-mono">
                  {paymentLink}
                </p>
              </div>

              {/* Amount Display */}
              {amount && (
                <div className="text-center mb-4">
                  <p className="text-2xl font-bold text-blue-600">
                    {formatCurrency(parseFloat(amount))}
                  </p>
                </div>
              )}
            </div>

            {/* Actions */}
            <div className="space-y-3">
              <Button
                onClick={() => handleCopy(paymentLink)}
                className="w-full h-12 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-xl flex items-center justify-center gap-2"
              >
                {copied ? <Check className="w-5 h-5" /> : <Copy className="w-5 h-5" />}
                {copied ? 'Lien copié !' : 'Copier le lien'}
              </Button>
              <Button
                variant="outline"
                onClick={handleShare}
                className="w-full h-12 rounded-xl border-gray-300 flex items-center justify-center gap-2"
              >
                <Share2 className="w-5 h-5" />
                Partager via...
              </Button>
            </div>

            {/* Social Share Options */}
            <div className="bg-white rounded-2xl p-4 shadow-sm">
              <p className="text-sm text-gray-500 mb-3 text-center">Partager sur</p>
              <div className="flex justify-center gap-4">
                {['WhatsApp', 'Facebook', 'SMS'].map((platform) => (
                  <button
                    key={platform}
                    onClick={() => toast.info(`${platform} - Intégration à venir !`)}
                    className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200 transition-colors"
                  >
                    <span className="text-xs font-medium text-gray-600">{platform[0]}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Info */}
            <div className="bg-blue-50 rounded-xl p-4">
              <h4 className="font-semibold text-blue-800 mb-2 flex items-center gap-2">
                <Link className="w-5 h-5" />
                Avantages du lien
              </h4>
              <ul className="text-sm text-blue-700 space-y-2 list-disc list-inside">
                <li>Fonctionne même sans l'application installée</li>
                <li>Le payeur peut choisir son mode de paiement</li>
                <li>Parfait pour les paiements en ligne</li>
              </ul>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
