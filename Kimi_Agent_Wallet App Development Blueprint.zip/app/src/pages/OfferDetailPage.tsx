import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  Check, 
  User, 
  Users, 
  Building2, 
  Wallet,
  Sparkles,
  Shield,
  Zap,
  Clock
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { MOBICASH_OFFERS } from '@/data/offers';
import { useAuth } from '@/hooks/useAuth';
import { toast } from 'sonner';

interface OfferDetailPageProps {
  offerId: string;
  onNavigate: (page: 'login' | 'signup' | 'dashboard' | 'send' | 'receive' | 'history' | 'offer' | 'market' | 'profile') => void;
}

export function OfferDetailPage({ offerId, onNavigate }: OfferDetailPageProps) {
  const { user: _user } = useAuth();
  const offer = MOBICASH_OFFERS.find(o => o.id === offerId);

  if (!offer) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-500">Offre non trouvée</p>
          <Button onClick={() => onNavigate('dashboard')} className="mt-4">
            Retour
          </Button>
        </div>
      </div>
    );
  }

  const getOfferIcon = (iconName: string) => {
    switch (iconName) {
      case 'User': return User;
      case 'Users': return Users;
      case 'Building2': return Building2;
      default: return Wallet;
    }
  };

  const Icon = getOfferIcon(offer.icon);

  const handleSubscribe = () => {
    if (offer.id === 'mobi-solo') {
      toast.info('Vous êtes déjà inscrit à Mobi-Solo !');
      return;
    }
    toast.success(`Redirection vers l'achat de ${offer.name}...`);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('fr-DZ', {
      style: 'currency',
      currency: 'DZD',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white px-4 py-4 flex items-center gap-4 border-b border-gray-100 sticky top-0 z-10">
        <button 
          onClick={() => onNavigate('dashboard')}
          className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center"
        >
          <ArrowLeft className="w-5 h-5 text-gray-600" />
        </button>
        <h1 className="text-xl font-semibold text-gray-800">{offer.name}</h1>
      </header>

      <div className="pb-24">
        {/* Hero Section */}
        <div className={`bg-gradient-to-br ${offer.color} p-6 text-white`}>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center"
          >
            <div className="w-24 h-24 bg-white/20 rounded-3xl flex items-center justify-center mx-auto mb-4 backdrop-blur-sm">
              <Icon className="w-12 h-12 text-white" />
            </div>
            <h2 className="text-3xl font-bold mb-2">{offer.name}</h2>
            <p className="text-white/90 text-lg mb-4">{offer.description}</p>
            <div className="inline-flex items-center gap-2 bg-white/20 rounded-full px-4 py-2 backdrop-blur-sm">
              <span className="text-2xl font-bold">
                {offer.price === 0 ? 'Gratuit' : formatCurrency(offer.price)}
              </span>
              {offer.price > 0 && <span className="text-white/80">/mois</span>}
            </div>
          </motion.div>
        </div>

        {/* Features */}
        <div className="p-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white rounded-2xl p-6 shadow-sm mb-6"
          >
            <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-500" />
              Ce qui est inclus
            </h3>
            <ul className="space-y-3">
              {offer.features.map((feature, index) => (
                <motion.li
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 + index * 0.05 }}
                  className="flex items-start gap-3"
                >
                  <div className={`w-6 h-6 rounded-full bg-gradient-to-br ${offer.color} flex items-center justify-center flex-shrink-0 mt-0.5`}>
                    <Check className="w-4 h-4 text-white" />
                  </div>
                  <span className="text-gray-700">{feature}</span>
                </motion.li>
              ))}
            </ul>
          </motion.div>

          {/* Benefits */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="grid grid-cols-3 gap-3 mb-6"
          >
            <div className="bg-white rounded-xl p-4 text-center shadow-sm">
              <div className="w-10 h-10 bg-emerald-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <Zap className="w-5 h-5 text-emerald-600" />
              </div>
              <p className="text-xs text-gray-500">Instantané</p>
            </div>
            <div className="bg-white rounded-xl p-4 text-center shadow-sm">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <Shield className="w-5 h-5 text-blue-600" />
              </div>
              <p className="text-xs text-gray-500">Sécurisé</p>
            </div>
            <div className="bg-white rounded-xl p-4 text-center shadow-sm">
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-2">
                <Clock className="w-5 h-5 text-purple-600" />
              </div>
              <p className="text-xs text-gray-500">24/7</p>
            </div>
          </motion.div>

          {/* Offer-specific info */}
          {offer.id === 'mobi-famille' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="bg-blue-50 rounded-xl p-4 mb-6"
            >
              <h4 className="font-semibold text-blue-800 mb-2">Parfait pour les familles</h4>
              <p className="text-sm text-blue-700 mb-3">
                Gérez les dépenses de toute votre famille depuis un seul compte. 
                Contrôlez les dépenses de vos enfants et envoyez-leur de l'argent de poche instantanément.
              </p>
              <div className="flex items-center gap-2 text-sm text-blue-600">
                <Users className="w-4 h-4" />
                <span>Jusqu'à 5 sous-comptes</span>
              </div>
            </motion.div>
          )}

          {offer.id === 'b2b' && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="bg-amber-50 rounded-xl p-4 mb-6"
            >
              <h4 className="font-semibold text-amber-800 mb-2">Pour les professionnels</h4>
              <p className="text-sm text-amber-700 mb-3">
                Acceptez les paiements sans TPE coûteux. Gérez votre trésorerie 
                et payez vos fournisseurs directement depuis votre compte.
              </p>
              <div className="flex items-center gap-2 text-sm text-amber-600">
                <Building2 className="w-4 h-4" />
                <span>Sans engagement</span>
              </div>
            </motion.div>
          )}

          {/* Comparison */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="bg-white rounded-2xl p-6 shadow-sm mb-6"
          >
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Comparaison des offres</h3>
            <div className="space-y-3">
              {MOBICASH_OFFERS.map((o) => (
                <div 
                  key={o.id}
                  className={`flex items-center justify-between p-3 rounded-xl ${
                    o.id === offer.id ? 'bg-emerald-50 border-2 border-emerald-200' : 'bg-gray-50'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${o.color} flex items-center justify-center`}>
                      <Check className="w-4 h-4 text-white" />
                    </div>
                    <span className={`font-medium ${o.id === offer.id ? 'text-emerald-800' : 'text-gray-600'}`}>
                      {o.name}
                    </span>
                  </div>
                  <span className={`text-sm ${o.id === offer.id ? 'text-emerald-600 font-semibold' : 'text-gray-500'}`}>
                    {o.price === 0 ? 'Gratuit' : formatCurrency(o.price) + '/mois'}
                  </span>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>

      {/* Bottom Action */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100 p-4">
        <div className="flex items-center justify-between gap-4">
          <div>
            <p className="text-sm text-gray-500">
              {offer.price === 0 ? 'Gratuit' : formatCurrency(offer.price) + '/mois'}
            </p>
            <p className="text-xs text-gray-400">
              {offer.id === 'mobi-solo' ? 'Déjà actif' : 'Annulation à tout moment'}
            </p>
          </div>
          <Button
            onClick={handleSubscribe}
            className={`h-12 px-6 rounded-xl font-semibold ${
              offer.id === 'mobi-solo'
                ? 'bg-gray-100 text-gray-500 cursor-default'
                : 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white hover:from-emerald-600 hover:to-teal-700'
            }`}
          >
            {offer.id === 'mobi-solo' ? 'Actif' : 'S\'abonner'}
          </Button>
        </div>
      </div>
    </div>
  );
}
