import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  ArrowLeft, 
  Wallet, 
  Smartphone, 
  User, 
  QrCode,
  Check,
  Sparkles
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/hooks/useAuth';
import { useTransactions } from '@/hooks/useTransactions';
import { toast } from 'sonner';

interface SendMoneyPageProps {
  onNavigate: (page: 'login' | 'signup' | 'dashboard' | 'send' | 'receive' | 'history' | 'offer' | 'market' | 'profile') => void;
}

type SendMethod = 'wallet' | 'flexy';
type WalletTransferMethod = 'phone' | 'contact' | 'qr';

export function SendMoneyPage({ onNavigate }: SendMoneyPageProps) {
  const { user } = useAuth();
  const { addTransaction } = useTransactions();
  const [sendMethod, setSendMethod] = useState<SendMethod>('wallet');
  const [walletMethod, setWalletMethod] = useState<WalletTransferMethod>('phone');
  const [step, setStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    recipientPhone: '',
    recipientName: '',
    amount: '',
    note: '',
  });
  const [showSuccess, setShowSuccess] = useState(false);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('fr-DZ', {
      style: 'currency',
      currency: 'DZD',
      minimumFractionDigits: 0,
    }).format(amount);
  };

  const handleSend = async () => {
    const amount = parseFloat(formData.amount);
    if (isNaN(amount) || amount <= 0) {
      toast.error('Veuillez entrer un montant valide');
      return;
    }

    const maxBalance = sendMethod === 'wallet' ? (user?.balance || 0) : (user?.flexyBalance || 0);
    if (amount > maxBalance) {
      toast.error('Solde insuffisant');
      return;
    }

    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 1500));

    addTransaction({
      type: 'send',
      amount,
      recipient: formData.recipientPhone,
      description: formData.note || `Transfert ${sendMethod === 'wallet' ? 'Wallet' : 'Flexy'}`,
      status: 'completed',
    });

    setIsLoading(false);
    setShowSuccess(true);
  };

  const resetForm = () => {
    setFormData({ recipientPhone: '', recipientName: '', amount: '', note: '' });
    setStep(1);
    setShowSuccess(false);
  };

  if (showSuccess) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="min-h-screen bg-gray-50 flex items-center justify-center p-4"
      >
        <div className="bg-white rounded-3xl shadow-xl p-8 text-center max-w-sm w-full">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', delay: 0.2 }}
            className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6"
          >
            <Check className="w-10 h-10 text-emerald-600" />
          </motion.div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Transfert réussi !</h2>
          <p className="text-gray-500 mb-2">
            {formatCurrency(parseFloat(formData.amount))} ont été envoyés
          </p>
          <p className="text-sm text-gray-400 mb-6">
            à {formData.recipientPhone}
          </p>
          <div className="space-y-3">
            <Button
              onClick={() => {
                resetForm();
                onNavigate('dashboard');
              }}
              className="w-full h-12 bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-semibold rounded-xl"
            >
              Retour à l'accueil
            </Button>
            <Button
              variant="outline"
              onClick={resetForm}
              className="w-full h-12 rounded-xl border-gray-300"
            >
              Nouveau transfert
            </Button>
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white px-4 py-4 flex items-center gap-4 border-b border-gray-100 sticky top-0 z-10">
        <button 
          onClick={() => onNavigate('dashboard')}
          className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center"
        >
          <ArrowLeft className="w-5 h-5 text-gray-600" />
        </button>
        <h1 className="text-xl font-semibold text-gray-800">Envoyer de l'argent</h1>
      </header>

      <div className="p-4">
        {/* Method Selection */}
        {step === 1 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            <h2 className="text-lg font-semibold text-gray-800 mb-4">Choisir la méthode</h2>
            
            {/* Wallet Option */}
            <motion.button
              onClick={() => {
                setSendMethod('wallet');
                setStep(2);
              }}
              whileTap={{ scale: 0.98 }}
              className={`w-full bg-white rounded-2xl p-5 border-2 transition-all ${
                sendMethod === 'wallet' 
                  ? 'border-emerald-500 shadow-lg' 
                  : 'border-gray-200 hover:border-emerald-300'
              }`}
            >
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl flex items-center justify-center">
                  <Wallet className="w-7 h-7 text-white" />
                </div>
                <div className="flex-1 text-left">
                  <h3 className="font-semibold text-gray-800 text-lg">Depuis mon Wallet</h3>
                  <p className="text-gray-500 text-sm">Solde: {formatCurrency(user?.balance || 0)}</p>
                </div>
                <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                  sendMethod === 'wallet' ? 'border-emerald-500 bg-emerald-500' : 'border-gray-300'
                }`}>
                  {sendMethod === 'wallet' && <Check className="w-4 h-4 text-white" />}
                </div>
              </div>
            </motion.button>

            {/* Flexy Option */}
            <motion.button
              onClick={() => {
                setSendMethod('flexy');
                setStep(2);
              }}
              whileTap={{ scale: 0.98 }}
              className={`w-full bg-white rounded-2xl p-5 border-2 transition-all ${
                sendMethod === 'flexy' 
                  ? 'border-emerald-500 shadow-lg' 
                  : 'border-gray-200 hover:border-emerald-300'
              }`}
            >
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center">
                  <Smartphone className="w-7 h-7 text-white" />
                </div>
                <div className="flex-1 text-left">
                  <h3 className="font-semibold text-gray-800 text-lg">Depuis mon Flexy</h3>
                  <p className="text-gray-500 text-sm">Solde: {user?.flexyBalance} DA</p>
                </div>
                <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                  sendMethod === 'flexy' ? 'border-emerald-500 bg-emerald-500' : 'border-gray-300'
                }`}>
                  {sendMethod === 'flexy' && <Check className="w-4 h-4 text-white" />}
                </div>
              </div>
            </motion.button>

            {/* Info Cards */}
            <div className="bg-emerald-50 rounded-xl p-4 mt-6">
              <h4 className="font-semibold text-emerald-800 mb-2 flex items-center gap-2">
                <Wallet className="w-5 h-5" />
                Wallet MOBICASH
              </h4>
              <p className="text-sm text-emerald-700">
                Transférez de l'argent instantanément vers n'importe quel compte MOBICASH, 
                par numéro de téléphone, contact ou QR code.
              </p>
            </div>

            <div className="bg-blue-50 rounded-xl p-4">
              <h4 className="font-semibold text-blue-800 mb-2 flex items-center gap-2">
                <Smartphone className="w-5 h-5" />
                Flexy Mobilis
              </h4>
              <p className="text-sm text-blue-700">
                Envoyez du crédit Flexy directement vers n'importe quel numéro Mobilis. 
                Simple et instantané.
              </p>
            </div>
          </motion.div>
        )}

        {/* Wallet Transfer Method Selection */}
        {step === 2 && sendMethod === 'wallet' && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-4"
          >
            <div className="flex items-center gap-2 mb-4">
              <button 
                onClick={() => setStep(1)}
                className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center"
              >
                <ArrowLeft className="w-4 h-4 text-gray-600" />
              </button>
              <h2 className="text-lg font-semibold text-gray-800">Comment envoyer ?</h2>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <motion.button
                onClick={() => {
                  setWalletMethod('phone');
                  setStep(3);
                }}
                whileTap={{ scale: 0.95 }}
                className="bg-white rounded-2xl p-4 border-2 border-gray-200 hover:border-emerald-300 flex flex-col items-center gap-2"
              >
                <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center">
                  <Smartphone className="w-6 h-6 text-emerald-600" />
                </div>
                <span className="text-sm font-medium text-gray-700">Par téléphone</span>
              </motion.button>

              <motion.button
                onClick={() => {
                  setWalletMethod('contact');
                  setStep(3);
                }}
                whileTap={{ scale: 0.95 }}
                className="bg-white rounded-2xl p-4 border-2 border-gray-200 hover:border-emerald-300 flex flex-col items-center gap-2"
              >
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                  <User className="w-6 h-6 text-blue-600" />
                </div>
                <span className="text-sm font-medium text-gray-700">Mes contacts</span>
              </motion.button>

              <motion.button
                onClick={() => {
                  setWalletMethod('qr');
                  setStep(3);
                }}
                whileTap={{ scale: 0.95 }}
                className="bg-white rounded-2xl p-4 border-2 border-gray-200 hover:border-emerald-300 flex flex-col items-center gap-2"
              >
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                  <QrCode className="w-6 h-6 text-purple-600" />
                </div>
                <span className="text-sm font-medium text-gray-700">Scan QR</span>
              </motion.button>
            </div>

            {/* Recommendation */}
            <div className="bg-gradient-to-r from-emerald-500 to-teal-600 rounded-2xl p-5 text-white mt-6">
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <Sparkles className="w-5 h-5" />
                Notre recommandation
              </h4>
              <p className="text-sm text-white/90 mb-3">
                Pour un transfert rapide, utilisez le <strong>numéro de téléphone</strong>. 
                C'est la méthode la plus utilisée par nos clients.
              </p>
              <Button
                onClick={() => {
                  setWalletMethod('phone');
                  setStep(3);
                }}
                className="bg-white text-emerald-600 hover:bg-gray-100 rounded-xl"
              >
                Continuer avec le téléphone
              </Button>
            </div>
          </motion.div>
        )}

        {/* Flexy Transfer - Direct to phone */}
        {step === 2 && sendMethod === 'flexy' && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-4"
          >
            <div className="flex items-center gap-2 mb-4">
              <button 
                onClick={() => setStep(1)}
                className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center"
              >
                <ArrowLeft className="w-4 h-4 text-gray-600" />
              </button>
              <h2 className="text-lg font-semibold text-gray-800">Envoyer du Flexy</h2>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="flexyPhone">Numéro du destinataire</Label>
                  <div className="relative">
                    <Smartphone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <Input
                      id="flexyPhone"
                      placeholder="05XX XX XX XX"
                      value={formData.recipientPhone}
                      onChange={(e) => setFormData({ ...formData, recipientPhone: e.target.value })}
                      className="pl-10 h-12 rounded-xl"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="flexyAmount">Montant (DA)</Label>
                  <Input
                    id="flexyAmount"
                    type="number"
                    placeholder="0"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    className="h-12 rounded-xl text-2xl font-bold text-center"
                  />
                  <p className="text-sm text-gray-500 text-center">
                    Solde disponible: {user?.flexyBalance} DA
                  </p>
                </div>

                <Button
                  onClick={handleSend}
                  disabled={isLoading || !formData.recipientPhone || !formData.amount}
                  className="w-full h-12 bg-gradient-to-r from-blue-500 to-indigo-600 text-white font-semibold rounded-xl"
                >
                  {isLoading ? (
                    <span className="flex items-center gap-2">
                      <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Envoi en cours...
                    </span>
                  ) : (
                    'Envoyer le Flexy'
                  )}
                </Button>
              </div>
            </div>
          </motion.div>
        )}

        {/* Wallet Transfer Form */}
        {step === 3 && sendMethod === 'wallet' && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-4"
          >
            <div className="flex items-center gap-2 mb-4">
              <button 
                onClick={() => setStep(2)}
                className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center"
              >
                <ArrowLeft className="w-4 h-4 text-gray-600" />
              </button>
              <h2 className="text-lg font-semibold text-gray-800">Détails du transfert</h2>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <div className="space-y-4">
                {walletMethod === 'phone' && (
                  <div className="space-y-2">
                    <Label htmlFor="walletPhone">Numéro du destinataire</Label>
                    <div className="relative">
                      <Smartphone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <Input
                        id="walletPhone"
                        placeholder="05XX XX XX XX"
                        value={formData.recipientPhone}
                        onChange={(e) => setFormData({ ...formData, recipientPhone: e.target.value })}
                        className="pl-10 h-12 rounded-xl"
                      />
                    </div>
                  </div>
                )}

                {walletMethod === 'contact' && (
                  <div className="space-y-2">
                    <Label>Sélectionner un contact</Label>
                    <div className="space-y-2 max-h-48 overflow-y-auto">
                      {[
                        { name: 'Karim Bensalem', phone: '0555123456' },
                        { name: 'Sofiane Amara', phone: '0555987654' },
                        { name: 'Fatima Zahra', phone: '0555345678' },
                      ].map((contact) => (
                        <button
                          key={contact.phone}
                          onClick={() => setFormData({ ...formData, recipientPhone: contact.phone, recipientName: contact.name })}
                          className={`w-full flex items-center gap-3 p-3 rounded-xl border-2 transition-all ${
                            formData.recipientPhone === contact.phone
                              ? 'border-emerald-500 bg-emerald-50'
                              : 'border-gray-200 hover:border-emerald-300'
                          }`}
                        >
                          <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
                            <User className="w-5 h-5 text-gray-500" />
                          </div>
                          <div className="flex-1 text-left">
                            <p className="font-medium text-gray-800">{contact.name}</p>
                            <p className="text-sm text-gray-500">{contact.phone}</p>
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {walletMethod === 'qr' && (
                  <div className="text-center py-8">
                    <div className="w-48 h-48 bg-gray-100 rounded-2xl mx-auto flex items-center justify-center mb-4">
                      <QrCode className="w-24 h-24 text-gray-400" />
                    </div>
                    <p className="text-gray-500">Scannez le QR code du destinataire</p>
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="walletAmount">Montant (DZD)</Label>
                  <Input
                    id="walletAmount"
                    type="number"
                    placeholder="0"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    className="h-12 rounded-xl text-2xl font-bold text-center"
                  />
                  <p className="text-sm text-gray-500 text-center">
                    Solde disponible: {formatCurrency(user?.balance || 0)}
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="note">Note (optionnel)</Label>
                  <Input
                    id="note"
                    placeholder="Ex: Remboursement déjeuner"
                    value={formData.note}
                    onChange={(e) => setFormData({ ...formData, note: e.target.value })}
                    className="h-12 rounded-xl"
                  />
                </div>

                <Button
                  onClick={handleSend}
                  disabled={isLoading || (!formData.recipientPhone && walletMethod !== 'qr') || !formData.amount}
                  className="w-full h-12 bg-gradient-to-r from-emerald-500 to-teal-600 text-white font-semibold rounded-xl"
                >
                  {isLoading ? (
                    <span className="flex items-center gap-2">
                      <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Envoi en cours...
                    </span>
                  ) : (
                    'Confirmer le transfert'
                  )}
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}


