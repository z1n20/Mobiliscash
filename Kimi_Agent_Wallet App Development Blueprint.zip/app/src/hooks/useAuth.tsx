import React, { createContext, useContext, useState, useCallback } from 'react';
import type { User, AuthContextType, SignupData } from '@/types';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Mock user for demo
const MOCK_USER: User = {
  id: '1',
  name: 'Ahmed Benali',
  email: 'ahmed@example.com',
  phone: '0555123456',
  nin: '1234567890123456',
  balance: 45000,
  flexyBalance: 1500,
};

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(MOCK_USER);
  const [isAuthenticated, setIsAuthenticated] = useState(true); // Auto-login for demo

  const login = useCallback(async (_email: string, _password: string) => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    setUser(MOCK_USER);
    setIsAuthenticated(true);
  }, []);

  const signup = useCallback(async (data: SignupData) => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    const newUser: User = {
      id: '2',
      name: data.name,
      email: data.email,
      phone: data.phone,
      nin: data.nin,
      balance: 0,
      flexyBalance: 0,
    };
    setUser(newUser);
    setIsAuthenticated(true);
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    setIsAuthenticated(false);
  }, []);

  return (
    <AuthContext.Provider value={{ user, isAuthenticated, login, signup, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
