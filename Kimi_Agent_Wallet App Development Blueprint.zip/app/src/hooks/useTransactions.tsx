import { useState, useCallback } from 'react';
import type { Transaction } from '@/types';

// Mock transactions
const MOCK_TRANSACTIONS: Transaction[] = [
  {
    id: '1',
    type: 'receive',
    amount: 5000,
    sender: 'Karim Bensalem',
    description: 'Remboursement',
    date: '2026-01-29T14:30:00',
    status: 'completed',
  },
  {
    id: '2',
    type: 'send',
    amount: 2500,
    recipient: 'Sofiane Amara',
    description: 'Déjeuner',
    date: '2026-01-28T12:15:00',
    status: 'completed',
  },
  {
    id: '3',
    type: 'purchase',
    amount: 1200,
    description: 'Recharge Flexy',
    date: '2026-01-27T09:00:00',
    status: 'completed',
  },
  {
    id: '4',
    type: 'send',
    amount: 10000,
    recipient: 'Fatima Zahra',
    description: 'Aide familiale',
    date: '2026-01-25T16:45:00',
    status: 'completed',
  },
  {
    id: '5',
    type: 'receive',
    amount: 15000,
    sender: 'Entreprise XYZ',
    description: 'Salaire',
    date: '2026-01-01T08:00:00',
    status: 'completed',
  },
];

export function useTransactions() {
  const [transactions, setTransactions] = useState<Transaction[]>(MOCK_TRANSACTIONS);

  const addTransaction = useCallback((transaction: Omit<Transaction, 'id' | 'date'>) => {
    const newTransaction: Transaction = {
      ...transaction,
      id: Date.now().toString(),
      date: new Date().toISOString(),
    };
    setTransactions(prev => [newTransaction, ...prev]);
    return newTransaction;
  }, []);

  const getTransactionById = useCallback((id: string) => {
    return transactions.find(t => t.id === id);
  }, [transactions]);

  return {
    transactions,
    addTransaction,
    getTransactionById,
  };
}
