// User types
export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  nin: string;
  balance: number;
  flexyBalance: number;
}

// Transaction types
export interface Transaction {
  id: string;
  type: 'send' | 'receive' | 'purchase';
  amount: number;
  recipient?: string;
  sender?: string;
  description: string;
  date: string;
  status: 'completed' | 'pending' | 'failed';
}

// Offer types
export interface Offer {
  id: string;
  name: string;
  description: string;
  price: number;
  features: string[];
  color: string;
  icon: string;
}

// Market offer types
export interface MarketOffer {
  id: string;
  category: 'tickets' | 'streaming' | 'gaming';
  title: string;
  description: string;
  price: number;
  image: string;
  badge?: string;
}

// Auth context type
export interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  signup: (data: SignupData) => Promise<void>;
  logout: () => void;
}

export interface SignupData {
  name: string;
  email: string;
  phone: string;
  nin: string;
  password: string;
}
