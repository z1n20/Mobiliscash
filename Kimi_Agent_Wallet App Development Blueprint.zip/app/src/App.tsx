import { useState } from 'react';
import { AuthProvider } from '@/hooks/useAuth';
import { LoginPage } from '@/pages/LoginPage';
import { SignupPage } from '@/pages/SignupPage';
import { DashboardPage } from '@/pages/DashboardPage';
import { SendMoneyPage } from '@/pages/SendMoneyPage';
import { ReceiveMoneyPage } from '@/pages/ReceiveMoneyPage';
import { TransactionHistoryPage } from '@/pages/TransactionHistoryPage';
import { OfferDetailPage } from '@/pages/OfferDetailPage';
import { MarketPage } from '@/pages/MarketPage';
import { ProfilePage } from '@/pages/ProfilePage';
import { BottomNav } from '@/components/BottomNav';
import { useAuth } from '@/hooks/useAuth';

type Page = 'login' | 'signup' | 'dashboard' | 'send' | 'receive' | 'history' | 'offer' | 'market' | 'profile';

function AppContent() {
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  const [selectedOfferId, setSelectedOfferId] = useState<string | null>(null);
  const { isAuthenticated } = useAuth();

  const navigateTo = (page: Page) => {
    setCurrentPage(page);
  };

  const handleOfferClick = (offerId: string) => {
    setSelectedOfferId(offerId);
    setCurrentPage('offer');
  };

  // Show auth pages if not authenticated
  if (!isAuthenticated) {
    if (currentPage === 'signup') {
      return <SignupPage onNavigate={navigateTo} />;
    }
    return <LoginPage onNavigate={navigateTo} />;
  }

  // Show main app pages
  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <DashboardPage onNavigate={navigateTo} onOfferClick={handleOfferClick} />;
      case 'send':
        return <SendMoneyPage onNavigate={navigateTo} />;
      case 'receive':
        return <ReceiveMoneyPage onNavigate={navigateTo} />;
      case 'history':
        return <TransactionHistoryPage onNavigate={navigateTo} />;
      case 'offer':
        return selectedOfferId ? (
          <OfferDetailPage offerId={selectedOfferId} onNavigate={navigateTo} />
        ) : (
          <DashboardPage onNavigate={navigateTo} onOfferClick={handleOfferClick} />
        );
      case 'market':
        return <MarketPage onNavigate={navigateTo} />;
      case 'profile':
        return <ProfilePage onNavigate={navigateTo} />;
      default:
        return <DashboardPage onNavigate={navigateTo} onOfferClick={handleOfferClick} />;
    }
  };

  const showBottomNav = ['dashboard', 'market', 'profile'].includes(currentPage);

  return (
    <div className="min-h-screen bg-gray-50">
      <main className="pb-20">
        {renderPage()}
      </main>
      {showBottomNav && (
        <BottomNav 
          currentPage={currentPage} 
          onNavigate={navigateTo} 
        />
      )}
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
