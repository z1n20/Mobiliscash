import type { Offer, MarketOffer } from '@/types';

export const MOBICASH_OFFERS: Offer[] = [
  {
    id: 'mobi-solo',
    name: 'Mobi-Solo',
    description: 'Votre compte personnel pour gérer votre argent au quotidien',
    price: 0,
    features: [
      'Paiement de factures (Sonelgaz, ADE, Algérie Télécom)',
      'Recharges Flexy automatiques',
      'Réservation de places de stade (QR Code exclusif)',
      'Réservation d\'hôtels (Partenariats nationaux)',
      'Épargne "Mkhaliyti" - Coffre-fort numérique',
      'Micro-crédit basé sur votre usage Mobilis',
    ],
    color: 'from-emerald-500 to-teal-600',
    icon: 'User',
  },
  {
    id: 'mobi-famille',
    name: 'Mobi-Famille',
    description: 'Un compte familial pour gérer les dépenses de toute la famille',
    price: 500,
    features: [
      'Compte principal avec sous-comptes enfants',
      'Transfert d\'argent de poche instantané',
      'Contrôle parental sur les dépenses',
      'Limites de dépenses personnalisables',
      'Épargne études pour l\'avenir des enfants',
      'Bonus Data offerts par Mobilis',
    ],
    color: 'from-blue-500 to-indigo-600',
    icon: 'Users',
  },
  {
    id: 'b2b',
    name: 'Mobi-Business',
    description: 'Solutions professionnelles pour commerçants et entreprises',
    price: 2000,
    features: [
      'QR Code d\'encaissement (remplace le TPE)',
      'Gestion de trésorerie intégrée',
      'Visibilité sur la carte des paiements',
      'Solution de billetterie complète',
      'Paiement des salaires aux ouvriers',
      'Collecte de fonds automatisée',
    ],
    color: 'from-amber-500 to-orange-600',
    icon: 'Building2',
  },
];

export const MARKET_OFFERS: MarketOffer[] = [
  // Tickets
  {
    id: 'ticket-l1',
    category: 'tickets',
    title: 'Mobilis Ligue 1',
    description: 'Billet pour les matchs de la Ligue 1 Mobilis',
    price: 500,
    image: 'https://images.unsplash.com/photo-1577223625816-7546f13df25d?w=400',
    badge: 'Populaire',
  },
  {
    id: 'ticket-l2',
    category: 'tickets',
    title: 'Mobilis Ligue 2',
    description: 'Billet pour les matchs de la Ligue 2',
    price: 300,
    image: 'https://images.unsplash.com/photo-1489944440615-453fc2b6a9a9?w=400',
  },
  // Streaming
  {
    id: 'netflix',
    category: 'streaming',
    title: 'Netflix',
    description: 'Abonnement Netflix 1 mois - Standard',
    price: 3500,
    image: 'https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?w=400',
    badge: 'Tendance',
  },
  {
    id: 'hbo',
    category: 'streaming',
    title: 'HBO Max',
    description: 'Abonnement HBO Max 1 mois',
    price: 2500,
    image: 'https://images.unsplash.com/photo-1522869635100-9f4c5e86aa37?w=400',
  },
  {
    id: 'amazon-prime',
    category: 'streaming',
    title: 'Amazon Prime',
    description: 'Abonnement Amazon Prime Video 1 mois',
    price: 2000,
    image: 'https://images.unsplash.com/photo-1616469829581-73993eb86b02?w=400',
  },
  // Gaming
  {
    id: 'gamepass',
    category: 'gaming',
    title: 'Xbox Game Pass',
    description: 'Abonnement Xbox Game Pass Ultimate 1 mois',
    price: 4500,
    image: 'https://images.unsplash.com/photo-1605901309584-818e25960a8f?w=400',
    badge: 'Nouveau',
  },
  {
    id: 'psplus',
    category: 'gaming',
    title: 'PlayStation Plus',
    description: 'Abonnement PS Plus Essential 1 mois',
    price: 3500,
    image: 'https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?w=400',
  },
];

export const BANNER_OFFERS = [
  {
    id: 'banner-1',
    title: 'Promo Stade',
    subtitle: '-20% sur les billets Ligue 1',
    color: 'from-red-500 to-rose-600',
  },
  {
    id: 'banner-2',
    title: 'Netflix Offert',
    subtitle: '3 mois avec Mobi-Famille',
    color: 'from-purple-500 to-violet-600',
  },
  {
    id: 'banner-3',
    title: 'Game Pass',
    subtitle: '1 mois à -50%',
    color: 'from-green-500 to-emerald-600',
  },
];
